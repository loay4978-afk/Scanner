# PaperScan Pro

Offline-first Flutter document scanner starter with GetX MVC, local SQLite storage, multi-page document management, manual crop editing, PDF export/sharing, and on-device text recognition.

## Build APK with GitHub Actions

1. Extract the contents of `App.zip` into the root of a GitHub repository.
2. Copy the separately supplied `Build.yml` to `.github/workflows/Build.yml`.
3. Push to the `main` branch (or run the workflow manually from Actions).
4. Download the `PaperScan-Pro-APK` artifact from the completed workflow.

The workflow generates the Android Gradle wrapper/platform scaffold using the selected Flutter stable SDK, then builds `app-release.apk`.

## Local build

Install Flutter stable and Android SDK, run `flutter pub get`, then `flutter build apk --release`.

## Current feature scope

- Camera capture and multi-image gallery import.
- Per-page manual crop/rotate adjustment through the native crop editor.
- Multi-page documents, page reordering, page deletion, and additional pages.
- Local SQLite document/folder index; image files remain in the app's private storage.
- A4 PDF generation, preview/print integration, and share-sheet export.
- On-device OCR using ML Kit Latin recognition.
- Arabic, English, and German UI strings.

Advanced automatic document-edge detection, shadow removal, perspective correction, invoice-field extraction, cloud sync, PDF merge/split/compression controls, and production-grade multilingual OCR are not claimed as implemented in this first build. These require dedicated scanner-engine work and device QA before a commercial release.
