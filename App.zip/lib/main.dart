import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'app/data/providers/database_provider.dart';
import 'app/translations/app_translations.dart';
import 'modules/home/home_binding.dart';
import 'modules/home/home_page.dart';
import 'modules/document/document_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await DatabaseProvider.instance.database;
  runApp(const PaperScanApp());
}

class PaperScanApp extends StatelessWidget {
  const PaperScanApp({super.key});
  @override
  Widget build(BuildContext context) => GetMaterialApp(
    title: 'PaperScan Pro', debugShowCheckedModeBanner: false,
    translations: AppTranslations(), locale: const Locale('ar'), fallbackLocale: const Locale('en'),
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF1769AA), brightness: Brightness.light),
      scaffoldBackgroundColor: const Color(0xFFF5F7FA), useMaterial3: true,
      appBarTheme: const AppBarTheme(backgroundColor: Color(0xFFF5F7FA), foregroundColor: Color(0xFF172B4D), elevation: 0)),
    initialBinding: HomeBinding(), home: const HomePage(),
    getPages: [GetPage(name: '/document', page: () => const DocumentPage())],
  );
}
