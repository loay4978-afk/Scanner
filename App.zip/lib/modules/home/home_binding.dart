import 'package:get/get.dart';
import '../../app/controllers/home_controller.dart';
class HomeBinding extends Bindings {@override void dependencies()=>Get.put(HomeController(),permanent:true);}
