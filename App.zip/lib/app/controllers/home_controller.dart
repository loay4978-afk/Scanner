import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:share_plus/share_plus.dart';
import 'package:uuid/uuid.dart';
import '../data/models/scan_document.dart';
import '../data/providers/database_provider.dart';
import '../services/scanner_service.dart';
import '../services/pdf_service.dart';
import '../services/ocr_service.dart';

class HomeController extends GetxController {
 final docs=<ScanDocument>[].obs; final folders=<ScanFolder>[].obs; final query=''.obs; final busy=false.obs; final selectedFolder=RxnString();
 final scanner=ScannerService(); final pdf=PdfService(); final ocr=OcrService(); final _uuid=const Uuid();
 @override void onInit(){super.onInit();load();}
 Future<void> load() async { final db=await DatabaseProvider.instance.database; final d=await db.query('documents',orderBy:'updated_at DESC'); final f=await db.query('folders',orderBy:'name COLLATE NOCASE'); docs.assignAll(d.map(ScanDocument.fromMap)); folders.assignAll(f.map(ScanFolder.fromMap)); }
 List<ScanDocument> get visibleDocs { final q=query.value.trim().toLowerCase(); return docs.where((d)=>(selectedFolder.value==null||d.folderId==selectedFolder.value)&&(q.isEmpty||d.title.toLowerCase().contains(q))).toList(); }
 Future<void> createFolder(String name) async { if(name.trim().isEmpty)return; final db=await DatabaseProvider.instance.database; await db.insert('folders',ScanFolder(_uuid.v4(),name.trim()).toMap()); await load(); }
 Future<void> startCapture() async => _newDocument(await scanner.capture());
 Future<void> importImages() async => _newDocument(await scanner.importMany());
 Future<void> _newDocument(List<String> paths) async { if(paths.isEmpty)return; final edited=<String>[]; for(final path in paths){edited.add(await scanner.crop(path));} final now=DateTime.now(); final doc=ScanDocument(id:_uuid.v4(),title:'${'app_title'.tr} ${docs.length+1}',pages:edited,createdAt:now,updatedAt:now); final db=await DatabaseProvider.instance.database; await db.insert('documents',doc.toMap()); await load(); Get.toNamed('/document',arguments:doc.id); }
 Future<void> addPages(ScanDocument doc) async { final added=await scanner.importMany(); if(added.isEmpty)return; final all=[...doc.pages]; for(final p in added){all.add(await scanner.crop(p));} await _save(doc.copyWith(pages:all)); }
 Future<void> editPage(ScanDocument doc,int index) async { final path=await scanner.crop(doc.pages[index]); final pages=[...doc.pages]; pages[index]=path; await _save(doc.copyWith(pages:pages)); }
 Future<void> removePage(ScanDocument doc,int index) async { final pages=[...doc.pages]..removeAt(index); if(pages.isEmpty){await deleteDocument(doc);Get.back();}else{await _save(doc.copyWith(pages:pages));} }
 Future<void> reorder(ScanDocument doc,int oldIndex,int newIndex) async { final pages=[...doc.pages]; if(newIndex>oldIndex)newIndex--; final item=pages.removeAt(oldIndex);pages.insert(newIndex,item);await _save(doc.copyWith(pages:pages)); }
 Future<void> rename(ScanDocument doc,String title) async {await _save(doc.copyWith(title:title));}
 Future<void> _save(ScanDocument doc) async {final db=await DatabaseProvider.instance.database;await db.update('documents',doc.toMap(),where:'id=?',whereArgs:[doc.id]);await load();}
 ScanDocument? find(String id){try{return docs.firstWhere((d)=>d.id==id);}catch(_){return null;}}
 Future<void> deleteDocument(ScanDocument doc) async {final db=await DatabaseProvider.instance.database;await db.delete('documents',where:'id=?',whereArgs:[doc.id]);for(final path in doc.pages){final f=File(path);if(await f.exists())await f.delete();}await load();}
 Future<File?> exportPdf(ScanDocument doc) async {try{busy.value=true;final f=await pdf.create(doc);Get.snackbar('app_title'.tr,'pdf_ready'.tr);return f;}catch(e){Get.snackbar('error'.tr,e.toString());return null;}finally{busy.value=false;}}
 Future<void> sharePdf(ScanDocument doc) async {final f=await exportPdf(doc);if(f!=null)await Share.shareXFiles([XFile(f.path)],text:doc.title);}
 Future<String> extractText(ScanDocument doc) async {busy.value=true;try{return await ocr.recognize(doc.pages);}finally{busy.value=false;}}
 Future<void> moveToFolder(ScanDocument doc,String? folderId) async {final updated=ScanDocument(id:doc.id,title:doc.title,pages:doc.pages,folderId:folderId,createdAt:doc.createdAt,updatedAt:DateTime.now());await _save(updated);}
}
