class ScanDocument {
 final String id, title; final List<String> pages; final String? folderId; final DateTime createdAt, updatedAt;
 const ScanDocument({required this.id, required this.title, required this.pages, this.folderId, required this.createdAt, required this.updatedAt});
 Map<String,Object?> toMap()=>{'id':id,'title':title,'pages':pages.join('|'),'folder_id':folderId,'created_at':createdAt.toIso8601String(),'updated_at':updatedAt.toIso8601String()};
 factory ScanDocument.fromMap(Map<String,Object?> m)=>ScanDocument(id:m['id'] as String,title:m['title'] as String,pages:(m['pages'] as String).split('|').where((e)=>e.isNotEmpty).toList(),folderId:m['folder_id'] as String?,createdAt:DateTime.parse(m['created_at'] as String),updatedAt:DateTime.parse(m['updated_at'] as String));
 ScanDocument copyWith({String? title,List<String>? pages,String? folderId})=>ScanDocument(id:id,title:title??this.title,pages:pages??this.pages,folderId:folderId??this.folderId,createdAt:createdAt,updatedAt:DateTime.now());
}
class ScanFolder { final String id,name; const ScanFolder(this.id,this.name); Map<String,Object?> toMap()=>{'id':id,'name':name}; factory ScanFolder.fromMap(Map<String,Object?> m)=>ScanFolder(m['id'] as String,m['name'] as String); }
