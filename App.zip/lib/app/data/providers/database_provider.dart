import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
class DatabaseProvider {
 DatabaseProvider._(); static final instance=DatabaseProvider._(); Database? _db;
 Future<Database> get database async { if(_db!=null)return _db!; final dir=await getApplicationDocumentsDirectory(); _db=await openDatabase(p.join(dir.path,'paperscan.db'),version:1,onCreate:(db,v)async{
  await db.execute('CREATE TABLE documents(id TEXT PRIMARY KEY,title TEXT NOT NULL,pages TEXT NOT NULL,folder_id TEXT,created_at TEXT NOT NULL,updated_at TEXT NOT NULL)');
  await db.execute('CREATE TABLE folders(id TEXT PRIMARY KEY,name TEXT NOT NULL)');
  await db.execute('CREATE INDEX idx_documents_updated ON documents(updated_at)');
 }); return _db!; }
}
