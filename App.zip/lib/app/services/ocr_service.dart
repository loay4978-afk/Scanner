import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
class OcrService {
 Future<String> recognize(List<String> paths) async {
  final detector=TextRecognizer(script:TextRecognitionScript.latin);
  try { final parts=<String>[]; for(final path in paths){ final result=await detector.processImage(InputImage.fromFilePath(path)); if(result.text.trim().isNotEmpty)parts.add(result.text); } return parts.join('\n\n──────────\n\n'); }
  finally { await detector.close(); }
 }
}
