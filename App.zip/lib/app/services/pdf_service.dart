import 'dart:io';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import '../data/models/scan_document.dart';
class PdfService {
 Future<File> create(ScanDocument doc) async {
  final pdf=pw.Document(compress:true);
  for(final path in doc.pages){ final file=File(path); if(!await file.exists())continue; final image=pw.MemoryImage(await file.readAsBytes()); pdf.addPage(pw.Page(pageFormat:PdfPageFormat.a4,margin:const pw.EdgeInsets.all(18),build:(_)=>pw.Center(child:pw.Image(image,fit:pw.BoxFit.contain)))); }
  final dir=await getApplicationDocumentsDirectory(); final out=Directory(p.join(dir.path,'exports')); await out.create(recursive:true);
  final safe=doc.title.replaceAll(RegExp(r'[^\w\- ]'),'_').trim(); final file=File(p.join(out.path,'${safe.isEmpty?'scan':safe}_${DateTime.now().millisecondsSinceEpoch}.pdf'));
  await file.writeAsBytes(await pdf.save(),flush:true); return file;
 }
}
