import 'dart:io';
import 'package:flutter/material.dart';
import 'dart:typed_data';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

/// Local-first image intake and editing. Original captures are retained; edits create new files.
class ScannerService {
 final ImagePicker _picker=ImagePicker();
 Future<List<String>> capture() async { final x=await _picker.pickImage(source:ImageSource.camera,imageQuality:100); return x==null?[]:[await _persist(File(x.path))]; }
 Future<List<String>> importMany() async { final xs=await _picker.pickMultiImage(imageQuality:100); final out=<String>[]; for(final x in xs){out.add(await _persist(File(x.path)));} return out; }
 Future<String> crop(String path) async { final result=await ImageCropper().cropImage(sourcePath:path,compressFormat:ImageCompressFormat.jpg,compressQuality:100,uiSettings:[AndroidUiSettings(toolbarTitle:'PaperScan Pro',toolbarColor:const Color(0xFF1769AA),toolbarWidgetColor:const Color(0xFFFFFFFF),lockAspectRatio:false,hideBottomControls:false),IOSUiSettings(title:'Adjust document')]); return result==null?path:await _persist(File(result.path)); }
 Future<String> _persist(File source) async { final dir=await getApplicationDocumentsDirectory(); final scans=Directory(p.join(dir.path,'scans')); await scans.create(recursive:true); final dest=p.join(scans.path,'${DateTime.now().microsecondsSinceEpoch}${p.extension(source.path).isEmpty?'.jpg':p.extension(source.path)}'); await source.copy(dest); return dest; }
 Future<Uint8List> optimizedBytes(String path) async { final bytes=await File(path).readAsBytes(); final result=await FlutterImageCompress.compressWithList(bytes,quality:96,format:CompressFormat.jpeg,keepExif:true); return result; }
}
